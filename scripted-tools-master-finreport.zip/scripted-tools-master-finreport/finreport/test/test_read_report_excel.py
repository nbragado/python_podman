import pytest


def test_read_report_peopleeffort_excel(self):
    # Create a mock ConfigObject
    config = MagicMock(spec=bc.ConfigObject)

    # Create an instance of CollectReportsData
    collect_reports_data = CollectReportsData(config)

    # Create a mock report file
    report = MagicMock()

    # Call the read_report_peopleeffort_excel method
    collect_reports_data.read_report_peopleeffort_excel('service_group', 'service', report)

    # Verify that the pd.read_excel function is called with the correct arguments
    pd.read_excel.assert_called_with(io=report, engine='openpyxl', sheet_name=collect_reports_data.people_sheet, skiprows=collect_reports_data.start_row)

    # Verify that the convert_peopleeffort_database method is called with the correct arguments
    collect_reports_data.convert_peopleeffort_database.assert_called_with(report_xls.fillna(0))
