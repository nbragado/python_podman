import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import copy

# import base.cmd_tools as ctool
import base.logger as log
import base.config as bc

class ProvideData():
    '''
    data to read sql data to provide it
    steamlit ready.
    '''
    def __init__(self, config: bc.ConfigObject):
        self.config = config
        self.logging = log.log_init(self.config.log_config)
        self.logging.debug("init get report data")
        self.dbname = config.db_name
        self.logging.debug(self.dbname)
        self.engine = create_engine('sqlite:///' + self.dbname)
        base = declarative_base()
        metadata = base.metadata
        metadata.create_all(self.engine)
        db_session = sessionmaker(bind=self.engine)
        self.dbsession = db_session()

    def get_services_from_db(self) -> list:
        """ Get all classes from the database
        Where a class represents a serice which contains one to many PCT projects

        Returns:
            list: list of all classes known in DB
        """
        
        services_req = ('SELECT DISTINCT class FROM Report')
        services = pd.read_sql_query(services_req, self.engine)

        return services['Class'].to_list()

    def get_management_data_for_service(self, service: str) -> pd.DataFrame:
        '''
        Get the management data for a specific service
        meter data  DISTINCT
        '''
        service_req = (f'SELECT class, Project, SubProject, Workpackage, Type, Period, isMonth, Costs FROM Report '
                       f'WHERE class = "{service}"'
                       )
        service_data = pd.read_sql_query(service_req, self.engine)

        return service_data
    
    def get_fin_data_for_service(self, service: str ) -> pd.DataFrame:
        """ Get the Service Provider View for GBS FIN for a specific service
            
        Args:
            service (str): provide the service (class in DB) name.

        Returns:
            pd.DataFrame: The dataframe contains alle relevant data to pass the data for the Service Provider View.
        """

        month_req = "Select DISTINCT(isMonth) From Report"
        month = pd.read_sql_query(month_req, self.engine)['isMonth'].unique()[0]
        if month == 0:
            fin_req = (f'SELECT Project, SubProject, FIN_Provider, FIN_Category, SUM(Costs) AS Plan FROM Report '
                        f'WHERE Class = "{service}" AND Period = 100 '
                        f'GROUP BY Project, SubProject, FIN_Category '
                        f'ORDER BY Project, SubProject, FIN_Provider, FIN_Category;')
            fin_data = pd.read_sql_query(fin_req, self.engine)
        else:
            month = month + 1
            fin_req = (f'SELECT TABLE_FORC.Project, TABLE_FORC.SubProject, TABLE_FORC.FIN_Provider, TABLE_FORC.FIN_Category, TABLE_ASIS.ASIS, TABLE_FORC.Forecast FROM '
	                   f'(SELECT Project, SubProject, FIN_Provider, FIN_Category, SUM(Costs) AS AsIs FROM Report '
	                   f'WHERE Class = "{service}" AND Period < {month} '
	                   f'GROUP BY Project, SubProject, FIN_Category '
	                   f'ORDER BY Project, SubProject, FIN_Provider, FIN_Category) TABLE_ASIS, '
	                   f'(SELECT Project, SubProject, FIN_Provider, FIN_Category, SUM(Costs) AS Forecast FROM Report '
	                   f'WHERE Class = "{service}" AND Period < 13 '
	                   f'GROUP BY Project, SubProject, FIN_Category '
	                   f'ORDER BY Project, SubProject, FIN_Provider, FIN_Category) TABLE_FORC ' 
                       f'WHERE TABLE_ASIS.Project = TABLE_FORC.Project AND TABLE_ASIS.SubProject = TABLE_FORC.SubProject '
                       f'and TABLE_ASIS.FIN_Category = TABLE_FORC.FIN_Category and TABLE_ASIS.FIN_Provider = TABLE_FORC.FIN_Provider')
            
            fin_data = pd.read_sql_query(fin_req, self.engine)
        
        return fin_data
    
    def get_gbs_data_for_service(self, service: str) -> pd.DataFrame:
        '''
        Get the fin (GBS FIN) data for a specific service

        '''
        dist_req = (f'SELECT * FROM CostDistribution WHERE Class = "{service}"')
        dist_data = pd.read_sql_query(dist_req, self.engine)
        companies = dist_data['Company'].unique()

        gbs_req = (f'SELECT Project, SubProject, GBS_Category, SUM(Costs) AS Costs FROM Report '
                   f'WHERE Class = "{service}" AND Period = 100 AND NOT SubProject = "Sonderbudget" '
                   f'GROUP BY Project, SubProject, GBS_Category '
                   f'ORDER BY Project, SubProject, GBS_Category; ')
        gbs_data = pd.read_sql_query(gbs_req, self.engine)
        
        services = gbs_data['Project'].unique()
        self.cost_dist = {}
        serv_dist = {}
   
        for comp in companies:
            for service in services:  
                calc_val = dist_data.loc[(dist_data['Company'] == comp) & (dist_data['Service'] == service) , ['Share','int-ext']]      
                if len(calc_val['Share']) > 0:
                    share = calc_val['Share'].iloc[0]
                else:
                    continue
                serv_dist[service] = share             
            self.cost_dist[comp] = copy.deepcopy(serv_dist)
        for comp in companies:
            self.comp = comp
            gbs_data[comp] = gbs_data.apply(self.set_company_share, axis=1)
        return gbs_data
    
    def set_company_share(self, row):
        '''
        Set the value for the company share
        '''
        for comp, services in self.cost_dist.items():
            if self.comp == comp:
                for service, share in services.items():
                    if service == row['Project']:
                        return row['Costs'] * share
                    
    def get_employees_and_hours(self, plancurrent: str) -> pd.DataFrame:
        '''
        Get the employee data and the written hours for either
        plan, forecast, current view
        '''
        if plancurrent == 'Plan' or plancurrent == 'Current' or plancurrent == 'Forecast':
            pass
        else:
            print(f'ERROR: Wrong value in plancurrent - {plancurrent}')
            return pd.DataFrame()

        pcf_dict = {'Plan': '= 100', 'Current': '<= Report.isMonth', 'Forecast': '< 99'}

        user_req = (f'SELECT Hour_Rates."index" AS "GID", Hour_Rates."LastName", Hour_Rates."FirstName", Hour_Rates."Department", Hour_Rates."GroupSupplier", Hour_Rates."User-Type", '
                    f'Hour_Rates."Work_Year" , sum(Report.h) AS "Hours" FROM Hour_Rates '
                    f'LEFT JOIN Report '
                    f'WHERE  Hour_Rates."index" = Report.Booking AND REport.Period {pcf_dict[plancurrent]} '
                    f'GROUP BY "GID"')

        user_hours_data = pd.read_sql_query(user_req, self.engine)
        user_hours_data.dropna(axis=0, how='any', inplace=True)

        return user_hours_data


def main():
    '''
    Just to inform inintended use...
    '''
    print("This is a helper class for streamlit")


if __name__ == "__main__":
    main()