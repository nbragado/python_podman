import pandas as pd

import base.cmd_tools as ctool
import base.logger as log
import base.config as bc

class provide_report_data():
    '''
    reorganize report data for the reporting
    '''
    def __init__(self, service_data: pd.DataFrame) -> None:
        self.service_data = service_data
    
    def cost_profit_income_table(self, period: int, subproject: str):
        '''
        Returns a simple table with Costs, Profit, Income
        per given workpackage and type
        '''
        budget = pd.DataFrame()
        fc_total = self.service_data.loc[(self.service_data['SubProject'] == subproject) & (self.service_data['Period'] < 100)]
        fc_costs = self.service_data.loc[(self.service_data['SubProject'] == subproject) & 
                                         (self.service_data['Period'] < 100) & 
                                         ((self.service_data['Type'] == 'PeopleEffort') | (self.service_data['Type'] == 'Costs')) ]
        fc_income = self.service_data.loc[(self.service_data['SubProject'] == subproject) &
                                       (self.service_data['Period'] < 100) &
                                       (self.service_data['Type'] == 'Income')]

        if fc_total['Costs'].sum() != 0.0:
            fc_total = fc_total.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "FC Profit"})
            fc_total['FC Profit'] =  fc_total['FC Profit'].apply(lambda x: x*-1)
            fc_costs = fc_costs.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "FC Costs"})
            # budget = pd.merge(fc_costs, fc_total, left_index=True, right_index=True)
            budget = fc_costs
            budget = budget.join(fc_total)
            fc_income = fc_income.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "FC Income"})
            fc_income['FC Income'] = fc_income['FC Income'].apply(lambda x: x*-1)
            if not fc_income.empty:
                budget = budget.join(fc_income)
            else:
                fc_income = { 'FC Income': [0.0]}
                fc_income = pd.DataFrame(data=fc_income, index=fc_costs.index.tolist())
                budget = budget.join(fc_income).fillna(0)
           
        ai_total = self.service_data.loc[(self.service_data['SubProject'] == subproject) & (self.service_data['Period'] <= period)]
        ai_costs = self.service_data.loc[(self.service_data['SubProject'] == subproject) & 
                                         (self.service_data['Period'] <= period) & 
                                         ((self.service_data['Type'] == 'PeopleEffort') | (self.service_data['Type'] == 'Costs')) ]
        ai_income = self.service_data.loc[(self.service_data['SubProject'] == subproject) &
                                          (self.service_data['Period'] <= period) &
                                          (self.service_data['Type'] == 'Income')]
        if ai_total['Costs'].sum() != 0.0:
            ai_total = ai_total.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "AsIs Profit"})
            ai_total['AsIs Profit'] =  ai_total['AsIs Profit'].apply(lambda x: x*-1)
            ai_costs = ai_costs.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "AsIs Costs"})
            budget = budget.join(ai_total)
            budget = budget.join(ai_costs)
            ai_income = ai_income.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "AsIs Income"})
            ai_income['AsIs Income'] = ai_income['AsIs Income'].apply(lambda x: x*-1)
            if not ai_income.empty:
                budget = budget.join(ai_income)
        else: 
            ai_costs = { 'AsIs Costs': [0.0]}
            ai_costs = pd.DataFrame(data=ai_costs, index=fc_costs.index.tolist())
            budget = budget.join(ai_costs).fillna(0)

        plan_total = self.service_data.loc[(self.service_data['SubProject'] == subproject) & (self.service_data['Period'] == 100)]
        plan_costs = self.service_data.loc[(self.service_data['SubProject'] == subproject) & 
                                           (self.service_data['Period'] == 100) & 
                                           ((self.service_data['Type'] == 'PeopleEffort') | (self.service_data['Type'] == 'Costs')) ]
        plan_income = self.service_data.loc[(self.service_data['SubProject'] == subproject) &
                                            (self.service_data['Period'] == 100) &
                                            (self.service_data['Type'] == 'Income')]
        if plan_total['Costs'].sum() != 0.0:
            plan_total = plan_total.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "Plan Profit"})
            plan_total['Plan Profit'] =  plan_total['Plan Profit'].apply(lambda x: x*-1)
            plan_costs = plan_costs.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "Plan Costs"})
            budget = budget.join(plan_total)
            budget = budget.join(plan_costs)
            plan_income = plan_income.groupby(by=['Workpackage']).sum(numeric_only=True)[['Costs']].rename(columns={"Costs": "Plan Income"})
            plan_income['Plan Income'] = plan_income['Plan Income'].apply(lambda x: x*-1)
            if not plan_income.empty:
                budget = budget.join(plan_income)
        workpackages = budget.index.values   

        return budget, workpackages
  

def main():
    '''
    Just to inform inintended use...
    '''
    print("This is a helper class for streamlit")


if __name__ == "__main__":
    main()