import argparse
import textwrap
import json
from cryptography.fernet import Fernet


def main():
    """ make a given JSON file safer by encrypting important
        parts such as password. You have to save an key file to en- and decrypt!
        The program lists each key and you can encrypt / leave the value. (Press c or l)


    Console App with the following import parameters
        --key         Location and Name of a key file to be created to hold the key for decryption. (optional)
        --config      Location and name of a config file where defined keys shall have encrypted values (mandatory)

    """

    parser = argparse.ArgumentParser(
        prog='ProgramName',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent('''\
            additional information:
                Create the JSON file including the unencrypted passwords.
                All keys in the file are displayed. 
                Enter c to encrypt the stored value or
                enter l to leave the value as is
                exactly the way
                I want it
            '''))
    parser.add_argument("-k", "--key", help="File to be created/read with the key (str)", type=str, required=True)
    parser.add_argument("-n", "--newkey", help="If passed a new key is generated",  action='store_true', required=False)
    parser.add_argument("-c", "--config", help="File to be used for config (str)", type=str, required=True)
    args = parser.parse_args()
    keyfile = args.key
    conffile = args.config
    if args.newkey:
        newkey = True
    else:
        newkey = False

    if newkey:
        try:
            key = Fernet.generate_key()
            with open(keyfile, 'wb') as kf:
                kf.write(key)
        except:
            print("Could not create key or key file!")
            raise
    else:
        try:
            with open(keyfile, "rb") as kf:
                key = kf.read()
        except FileNotFoundError:
            print("Could not find the key file " + keyfile + "!")

    f = Fernet(key)

    # open config file
    try:
        with open(conffile, 'r', encoding='utf8') as cf:
            data = json.load(cf)
    except FileNotFoundError:
        print("Could not find the config file " + conffile + "!")
        raise

    for key, value in data.items():
        var = input("Encrypt the value for " + key +"? (y/n) ")
        if var == "y":
            if value[0:2] == "${" and value[-1:] == "}":
                print("value is already encrypted. ")
                continue
            else:
                byte_val = bytes(value, "UTF-8")
                encr_val = "${" + f.encrypt(byte_val).decode("UTF-8") + "}"
                data[key] = encr_val
                print(encr_val)
        else:
            print("leave key " + key + "untouched...")
    try:
        with open(conffile, 'w') as cf:
            json.dump(data, cf, ensure_ascii=False)
    except FileNotFoundError:
        print("Could not find the config file " + conffile + "!")
        raise
    print("Confile Created/Updated")


if __name__ == "__main__":
    main()


