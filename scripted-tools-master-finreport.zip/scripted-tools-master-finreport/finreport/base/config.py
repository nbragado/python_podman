import json
import sys
from json.decoder import JSONDecodeError

# cryptography package
from cryptography.fernet import Fernet


class ConfigObject():
    '''
    dataclass to store the config
    parameters
    '''

    db_name: str
    sap_files: str
    companies: str
    year: int
    pct_files: str
    report_folder: str
    # Logger File Name
    log_config: str

    def __init__(self, file_name: str, keyfile: str = ''):
        '''
        read the configuration file - based on JSON and return all keys with the decrypted values.
        Add encrypted values using create_enc_config.py

        Input parameters:
            filename: The JSON file holding the config data
            keyfile: THe key to decrypt your confidential data

        Returns as an dictionary the stored configuration.
        '''
        if keyfile != '':
            # open key file
            try:
                with open(keyfile, 'rb') as kf:
                    key = kf.read()
                    f = Fernet(key)
            except FileNotFoundError:
                print("Could not find the key file " + keyfile + "!")

        # open config file
        try:
            with open(file_name, 'r', encoding='utf8') as cf:
                data = json.load(cf)
        except (FileNotFoundError, JSONDecodeError) as ex_json:
            print('Exception in ' + file_name + ': ' + str(ex_json))
            sys.exit(1)

        for key, value in data.items():
            if keyfile != '':
                if str(value)[0:2] == "${" and str(value)[-1:] == "}":
                    enc_value = value[2:-1]
                    enc_value = bytes(enc_value, "UTF-8")
                    try:
                        dec_value = f.decrypt(enc_value).decode("UTF-8")
                    except:
                        print(
                            "Key " + str(key) + " has invalid value, can not decrypt. File manipulated?")
                        raise
                    data[key] = dec_value
        self.db_name = data['database']
        self.pct_file = data['pct_files']
        self.companies = data['companies']
        self.sap_files = data['sap_files']
        self.report_folder = data['report_folder']
        self.year = data['year']
        self.log_config = data['log_config']
        self.nrsno2name = data['nrs-no2name']
        self.pctstructure = data['pct-structure']
        self.ldap = {}
        self.ldap['user'] = data["proxy-user"]
        self.ldap['password'] = data["proxy-password"]
        self.ldap['server'] = data["proxy-server"]
        self.proxy_base = data['proxy-base']
        self.hourrate = data['hour_rate_file']
        self.all_rate = data['user-all_rate']
        self.pctproject2service = data['service2pctproject']
        self.hours_per_week = data['hours_per_week']
        self.annual_work_country = data['annual_work_country']


# Let other know, that this is just an interface class
if __name__ == "__main__":
    print('This is just an interface')
