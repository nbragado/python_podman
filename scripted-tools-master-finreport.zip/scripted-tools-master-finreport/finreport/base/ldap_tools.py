import copy
import logging
import sys
from datetime import datetime

from ldap3 import Connection, Server
from ldap3.core.exceptions import LDAPSocketOpenError


def ldap2dict(ldapresult, attributes, idattribute):
    """
    Ldap Attributes of the query that needs to passed in a dict.
    Pass the identifying ldap attribute (the key of the dictionary) to this function: i.e. employeeNumber or tcgid
    """
    record = {}
    records = {}
    for element in ldapresult:
        for attribute in attributes:
            if attribute in element['attributes']:
                if isinstance(element['attributes'][attribute],list):
                    # type(element['attributes'][attribute]) is list:
                    if not element['attributes'][attribute]:
                        record[attribute] = ''
                    else:
                        record[attribute] = element['attributes'][attribute][0]
                else:
                    if isinstance(element['attributes'][attribute], datetime):
                        # type(element['attributes'][attribute]) is datetime:
                        record[attribute] = element['attributes'][attribute].strftime("%Y-%m-%d")
                    else:
                        record[attribute] = element['attributes'][attribute]
            else:
                record[attribute] = ""
        record['dn'] = element['dn']
        records[record[idattribute]] = copy.deepcopy(record)
    return records


def ldap_mult_dict(ldapresult, attributes, idattribute):
    """
    ldap result of an LDAP query
    Ldap Attributes of the query that needs to passed in a dict.
    Pass the identifying ldap attribute (the key of the dictionary) to this function: i.e. employeeNumber or tcgid
    """
    record = {}
    records = {}
    for element in ldapresult:
        for attribute in attributes:
            if isinstance(element['attributes'][attribute], list):
                if len(element['attributes'][attribute]) == 1:
                    record[attribute] = element['attributes'][attribute][0]
                elif not element['attributes'][attribute]:
                    record[attribute] = ''
                else:
                    record[attribute] = list()
                    for ele in element['attributes'][attribute]:
                        record[attribute].append(ele)
                    record[attribute].sort()
            else:
                if isinstance(element['attributes'][attribute], datetime):
                    # type(element['attributes'][attribute]) is datetime:
                    record[attribute] = element['attributes'][attribute].strftime("%Y-%m-%d")
                else:
                    record[attribute] = element['attributes'][attribute]
        record['dn'] = element['dn']
        records[record[idattribute]] = copy.deepcopy(record)
    return records


def printresult(timestart, number_result):
    """
    Print the result of a TBA Analysis to the screen.
    """
    nowend = datetime.now()
    reqtime = nowend - timestart
    print("request took " + str(reqtime) + " to complete.")
    print("Time: " + nowend.strftime("%Y-%m-%d %H:%M:%S") + " TBAs: " + str(number_result))


def print_result(dic, attribute):
    '''
    Print the ldap2dict result to screen
    '''
    header = ""
    for i in attribute:
        val = i.ljust(15)
        header = header + val
    print(header)

    for ele in dic:
        line = ""
        for item1 in attribute:
            val = str(dic[ele][item1])
            line = line + val.ljust(15)
        print(line)


def ldap_bind(config, port = 636, use_ssl = True):
    '''
    config = the connection data to the ldap server
    '''
    logger = logging.getLogger("IAM logger")

    logger.debug("Connecting to ldap...")
    try:
        s = Server(host=config['server'], use_ssl=use_ssl, port=port, get_info='ALL')
        c = Connection(s, version = 3,
                       user = config['user'],
                       password = config['password'],
                       auto_referrals = True,
                       check_names = True,
                       read_only = False,
                       lazy = False,
                       raise_exceptions = False)
        logger.debug("Conection Parameters to LDAP initiated...")

        if not c.bind():
            print('error in bind', c.result)
            logger.error("Error binding to LDAP, exit program")
            sys.exit(1)
            # Eigentlich müsste hier eine Exception geworfen werden.

    except LDAPSocketOpenError as ldap_error:
        logger.error(ldap_error)
        logger.error('LDAP Conncetion Refused')
        print('Exception: ' + str(ldap_error))
        sys.exit(1)
    return c


def ldap_unbind(connection):
    '''
    unbind given ldap connection
    '''
    logger = logging.getLogger("IAM logger")

    logger.debug(connection)
    connection.unbind()
    logger.debug("unbind executed...")


def ldap_query(base, query, attributes, connection):
    '''
    query an ldap based on given paramenters
    '''
    logger = logging.getLogger("IAM logger")
    entries = connection.extend.standard.paged_search(base,
                                                      query,
                                                      attributes=attributes,
                                                      paged_size=2000)
    logger.debug("executed LDAP query. Filter: " + query + " with base: " + base)
    result = list(entries)
    return result
