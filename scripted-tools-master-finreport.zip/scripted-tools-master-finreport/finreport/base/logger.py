import sys
import logging
from logging.handlers import RotatingFileHandler
import json
from json.decoder import JSONDecodeError
import os


def log_init(logfile: str = "logger.config"):
    '''
    Init log process
    '''

    try:
        with open(logfile, 'r') as fp:
            logconfig = json.load(fp)
    except (FileNotFoundError, JSONDecodeError):
        print('>>logger.config<< not found. It must be in the same directory as the program file or file is corrupt. Can not continue!\n')
        sys.exit(1)

    tempus = logconfig['level']
    templevel = tempus.upper()
    logconfig['level'] = logging.INFO

    should_roll_over = os.path.isfile(logconfig['filename'])
    #handler = logging.handlers.RotatingFileHandler(logconfig['filename'], mode='w', backupCount=5)

    if templevel == "CRITICAL":
        logconfig['level'] = logging.CRITICAL
    if templevel == "ERROR":
        logconfig['level'] = logging.ERROR
    if templevel == "WARNING":
        logconfig['level'] = logging.WARNING
    if templevel == "INFO":
        logconfig['level'] = logging.INFO
    if templevel == "DEBUG":
        logconfig['level'] = logging.DEBUG
    
    handler = RotatingFileHandler(logconfig['filename'], mode='a', maxBytes=5*1024*1024, backupCount=5, delay=False)
    #if should_roll_over:  # log already exists, roll over!
    #    handler.doRollover()
    # logging.addHandler(handler)
    logging.basicConfig(filename = logconfig['filename'],
                        format = "%(asctime)s [ %(threadName)s ] [ %(levelname)s ] : %(message)s'",
                        datefmt = logconfig['datefmt'],
                        level = logconfig['level'])
    return logging

