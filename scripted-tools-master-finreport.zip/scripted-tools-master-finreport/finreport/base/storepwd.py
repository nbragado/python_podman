import getopt
import sys
import base64
import logging
import json
from json.decoder import JSONDecodeError

import base.config as bc
import base.logger as bl

def usage():
    msgcall = "storepwd.py -f <file>"
    print('storepwd adds or changes the password of a given JSON formed file. It will not be readable by human beings...\n' + msgcall)
    sys.exit()


# Store passwords in a secret.txt file for further PROCESSING_INSTRUCTION
logging = bl.log_init()


fileName =''

try:
    opts, args = getopt.getopt(sys.argv[1:],"hf:",["file="])
    logging.debug("read file name")
except getopt.GetoptError:
    usage()
    logging.debug("Error, options not used...")

for opt, arg in opts:
    if opt == '-h':
        usage()
        logging.debug("used Option -h")
    elif opt in ("-f", "--file"):
        fileName = arg
        logging.debug("used Option -f")

if fileName == '':
        usage()
        logging.debug("no option used to specify file")


kwords = bc.readfile(fileName)
logging.debug("read file")

pwd = input("Enter password: ")
pwdb64 = base64.b64encode(bytes(pwd, 'utf-8'))

kwords["password"]=str(pwdb64,'utf-8')

# Speichern in JSON Array...
with open(fileName, 'w') as outfile:
    json.dump(kwords,outfile, ensure_ascii=False)
print("File " + fileName + " updated/created.")

