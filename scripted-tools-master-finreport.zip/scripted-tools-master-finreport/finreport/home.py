import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import get_reports_data as grd
import process_reports_data as prd
import base.config as bc

# Page Icons
# https://www.webfx.com/tools/emoji-cheat-sheet/

def calc_height(no_rows: int):
    min_height = 200
    return no_rows * 50 + min_height

def highlight_income(x):
    '''
    Highlight the amount of hours too much or too less
    '''
    if float(x) < 0:
        return 'background-color: blue'

def left_align(s, props='text-align: right;'):
    return props

if 'Period' not in st.session_state:
    st.session_state['Period'] = 0
   
config_name = '../fintech/fin_report_2023.config'
config = bc.ConfigObject(file_name = config_name)

st.session_state['Config'] = config_name


st.set_page_config(
    page_title = "Management Overview",
    page_icon = ":office:",
    layout = "wide"
)

service_data = grd.ProvideData(config)
services = service_data.get_services_from_db()

it_service = st.sidebar.selectbox("Select the Service:", options = services)

if it_service:
    st.title(":green[" + it_service + " Management Overview]",)
    service_parameters = service_data.get_management_data_for_service(it_service)

    cat = st.sidebar.multiselect('Select the category:',
                                 options = service_parameters['SubProject'].unique(),
                                 default = service_parameters['SubProject'].unique())

    typ = service_parameters['Type'].unique()

    prt = st.sidebar.multiselect('Select the cost PCT Project:',
                                 options = service_parameters['Project'].unique(),
                                 default = service_parameters['Project'].unique())

    serviceinfo = service_data.get_management_data_for_service(it_service)
    service_filter = serviceinfo.query("SubProject == @cat & Project == @prt")
    service_subprojects = serviceinfo.drop_duplicates('SubProject')['SubProject'].to_list()
    service_helper = prd.provide_report_data(service_filter)
    if not prt or not cat:
        st.text('No data...')
        st.header('Please select value in the navigation bar on the left.')
        st.stop()
    is_month = int(service_filter['isMonth'].mean() + 1)
    st.session_state['Period'] = is_month - 1
    st.text(f'Report Period: {is_month-1}')
   

    # Background tasks
    # Create table for management overview
    line_income = ""
    line_costs = ""
    my_table_overview = {}
    total_forecast_costs = 0.0
    total_asis_costs = 0.0
    total_plan_costs = 0.0
    total_forecast_income = 0.0
    total_plan_income = 0.0
    s_profit = 0.0
    s_percent_profit = 0.0
    s_ref = 0.0
    
    # style the output.
    mapper = {}
    mapper['Plan'] = '{0:,.2f} EUR'
    mapper['Forecast'] = '{0:,.2f} EUR'
    mapper['As Is'] = '{0:,.2f} EUR'
    
    for rowname in typ:
        as_is = service_filter.loc[(service_filter['Period'] < is_month)
                                & (service_filter['Type'] == rowname),
                                ['Costs']].sum().tolist()[0]
        forecast = service_filter.loc[(service_filter['Period'] < 13)
                                    & (service_filter['Type'] == rowname),
                                    ['Costs']].sum().tolist()[0]
        plan = service_filter.loc[(service_filter['Period'] == 100)
                                & (service_filter['Type'] == rowname),
                                ['Costs']].sum().tolist()[0]
        if rowname == 'Income':
            total_forecast_income = forecast
            total_plan_income = plan
            # Dataframe
            my_table_overview[rowname] = [as_is, forecast, plan]           
        else:
            my_table_overview[rowname] = [as_is, forecast, plan]
            total_forecast_costs = forecast + total_forecast_costs
            total_asis_costs = as_is + total_asis_costs
            total_plan_costs = plan + total_plan_costs
    #  Dataframe for Overview 
    my_table_overview['Total Costs'] = [ total_asis_costs, total_forecast_costs, total_plan_costs]
     
    pd_overview = pd.DataFrame.from_dict(my_table_overview, orient='index',
                    columns=['As Is', 'Forecast','Plan'])
    
    pd_cost_income = pd_overview.loc[['Total Costs', 'Income']]
    pd_cost_income.loc['Profit/Loss'] = pd_cost_income.sum(numeric_only=True)
    pd_cost_income = pd_cost_income.style.format(mapper)
        
    pd_pe_cost = pd_overview.loc[['PeopleEffort', 'Costs']]
    pd_pe_cost.loc['Total Costs'] = pd_pe_cost.sum(numeric_only=True)
    pd_pe_cost = pd_pe_cost.style.format(mapper)

    # Show the highlight number as metric
    s_profit = (total_forecast_costs + total_forecast_income) * -1
    fig_highlights = go.Figure()
    if total_forecast_income != 0:
        # s_profit = (total_forecast_costs + total_forecast_income) * -1
        s_percent_profit = (abs(total_forecast_income) / total_forecast_costs) *100 - 100
        s_ref = s_profit * (total_forecast_costs / (total_forecast_income * -1) )
    else:
        s_percent_profit = -100
        s_ref = s_profit * -1
            
    lc, mc, rc = st.columns(3)
    
    with lc:
        if s_profit > 0:
            st.metric("Profit FY", f'{s_profit:,.2f} EUR', f'{((s_percent_profit)):,.1f}% Profit')
        else:
            st.metric("Profit FY", f'{s_profit:,.2f} EUR', f'{((s_percent_profit)):,.1f}% Loss')
    with mc:
        st.metric("Income FY", f'{total_forecast_income *-1:,.0f} EUR',f'{total_forecast_income-total_plan_income:,.0f} EUR compared to plan.' )
    st.markdown('---')
    
    # use 
    leftcol, rightcol = st.columns(2)
    with rightcol:
        st.markdown('Income and Total Costs')
        st.dataframe(pd_cost_income, use_container_width=True)
        
        st.markdown('People Effort and other Costs')
        st.dataframe(pd_pe_cost, use_container_width=True)
  
    with leftcol:
         if total_plan_costs != 0:
            if total_plan_costs > total_forecast_costs:
                limit = total_plan_costs
            else:
                limit = total_forecast_costs
            fig_gauge = go.Figure(go.Indicator(
                domain = {'x': [0, 1], 'y': [0, 1]},
                value = total_asis_costs,
                mode = "gauge",
                title = {'text': "Cost - As Is / ForeCast"},
                gauge = {'axis': {'range': [None, limit]},
                            'steps': [
                                    {'range': [0, total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [total_forecast_costs/12, 2*total_forecast_costs/12], 'color': "gray"},
                                    {'range': [2*total_forecast_costs/12, 3*total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [3*total_forecast_costs/12, 4*total_forecast_costs/12], 'color': "gray"},
                                    {'range': [4*total_forecast_costs/12, 5*total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [5*total_forecast_costs/12, 6*total_forecast_costs/12], 'color': "gray"},
                                    {'range': [6*total_forecast_costs/12, 7*total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [7*total_forecast_costs/12, 8*total_forecast_costs/12], 'color': "gray"},
                                    {'range': [8*total_forecast_costs/12, 9*total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [9*total_forecast_costs/12, 10*total_forecast_costs/12], 'color': "gray"},
                                    {'range': [10*total_forecast_costs/12, 11*total_forecast_costs/12], 'color': "lightgray"},
                                    {'range': [11*total_forecast_costs/12, 12*total_forecast_costs/12], 'color': "gray"},],
                            'threshold': {'line': {'color': "red", 'width': 4}, 'thickness': 0.75, 'value': total_plan_costs}}))
            st.plotly_chart(fig_gauge)

    
    if 'Operation' in cat:
        # Plot to show the Operation and associated costs
        sub_prj = 'Operation'
        st.subheader(sub_prj)
        sb, workpack = service_helper.cost_profit_income_table(is_month-1, sub_prj)
        sb.rename(index={'[All]': 'PeopleEffort'}, inplace=True)
        workpack = workpack.tolist()
        workpack.append('Select...')
        if len(sb.index) == 0:
            st.text('No Data selected')
        else:
            fig_bar = px.bar(sb, y=sb.index,
                             x=['AsIs Costs', 'FC Costs'],
                            barmode='group',
                            orientation='h',
                            height=calc_height(len(sb.index)),
                            labels={
                                "variable": "Category",
                                "value": "Budget in EUR"
                                },
                            )
            st.plotly_chart(fig_bar)


    if 'CR' in cat:
        st.markdown('People Effort and other Costs')


        # Plot to show the Change Request and associated costs
        sub_prj = 'CR'
        st.subheader(sub_prj)
        sb, workpack = service_helper.cost_profit_income_table(is_month-1, sub_prj)
        workpack = workpack.tolist()
        if len(sb.index) == 0:
            st.text('No Data selected')
        else:
            fig_bar = px.bar(sb, y=sb.index,
                        x=['AsIs Costs', 'FC Costs'],
                        barmode='group',
                        orientation='h',
                        height=calc_height(len(sb.index)),
                        labels={
                            "variable": "Category",
                            "value": "Budget in EUR"
                            },
                        )
            st.plotly_chart(fig_bar)
        # Plot to show the Sonderbudget and associated costs
        sub_prj = 'Sonderbudget'
        sb, workpack = service_helper.cost_profit_income_table(is_month-1, sub_prj)
        workpack = workpack.tolist()
        workpack.append('Select...')
        if len(sb.index) == 0:
            st.text('No Data selected')
        else:
            st.subheader(sub_prj)

            if sub_prj == 'Sonderbudget' and "Income" in typ:
                fig_bar = px.bar(sb, y=sb.index,
                            x=['FC Costs', 'FC Income'],
                            height=calc_height(len(sb.index)),
                            barmode='group',
                            orientation='h'
                            )
                st.plotly_chart(fig_bar)
                default_ix = workpack.index('Select...')
                wp_selection = st.selectbox("Package:", options = workpack, index=default_ix, key = "sp_package")
                if wp_selection != 'Select...':
                    row = sb.loc[sb.index == wp_selection].squeeze()
                    fig = go.Figure(go.Waterfall(name = "20", orientation = "h",
                                                 measure = ['absolute', 'relative', 'total', 'absolute', 'relative', 'total' ],
                                                 textposition = "outside",
                                                 y = ["FC Costs", "FC Profit", "FC Income", "AsIs Costs", "AsIs Profit", "AsIs Income"],
                                                 x = [row['FC Costs'], row['FC Profit'], row['FC Income'], row['AsIs Costs'], row['AsIs Profit'], row['AsIs Income']],
                                                 decreasing = {"marker":{"color":"Maroon"}},
                                                 increasing = {"marker":{"color":"Teal"}},
                                                 connector = {"line":{"color":"rgb(63, 63, 63)"}}))
                    fig.update_layout(title = wp_selection, waterfallgap = 0.3,  height=(calc_height(len(sb.index))+100))
                    st.plotly_chart(fig)
            else:
                fig_bar = px.bar(sb, y=sb.index,
                            x=['AsIs Costs', 'FC Costs'],
                            height=calc_height(len(sb.index)),
                            barmode='group',
                            orientation='h',
                            labels={
                                "variable": "Category",
                                "value": "Budget in EUR"
                                },
                            )
                st.plotly_chart(fig_bar)
        # Plot to show the Sonderbudget and associated costs
        sub_prj = 'Projekt'
        sb, workpack = service_helper.cost_profit_income_table(is_month-1, sub_prj)
        workpack = workpack.tolist()
        workpack.append('Select...')
        if len(sb.index) != 0:
            st.subheader(sub_prj)
            if sub_prj == 'Projekt' and "Income" in typ:
                fig_bar = px.bar(sb, y=sb.index,
                            x=['FC Costs', 'FC Income'],
                            height=calc_height(len(sb.index)),
                            barmode='group',
                            orientation='h'
                            )
                st.plotly_chart(fig_bar)
                default_ix = workpack.index('Select...')
                wp_selection = st.selectbox("Package:", options = workpack, index=default_ix, key= 'pr_package')
                if wp_selection != 'Select...':
                    row = sb.loc[sb.index == wp_selection].squeeze()
                    fig = go.Figure(go.Waterfall(name = "20", orientation = "h",
                                                measure = ["absolute", "relative", "total"],
                                                textposition = "outside",
                                                y = ["FC Costs", "FC Profit", "FC Income"],
                                                x = [row['FC Costs'], row['FC Profit'], row['FC Income']],
                                                decreasing = {"marker":{"color":"Maroon"}},
                                                increasing = {"marker":{"color":"Teal"}},
                                                connector = {"line":{"color":"rgb(63, 63, 63)"}}))
                    fig.update_layout(title = wp_selection, waterfallgap = 0.3,  height=(calc_height(len(sb.index))))
                    st.plotly_chart(fig)
            else:
                fig_bar = px.bar(sb, y=sb.index,
                            x=['AsIs Costs', 'FC Costs'],
                            height=calc_height(len(sb.index)),
                            barmode='group',
                            orientation='h',
                            labels={
                                "variable": "Category",
                                "value": "Budget in EUR"
                                },
                            )
                st.plotly_chart(fig_bar)


    st.markdown('---')
   
    stat_float_col = ['Costs']
    mapper = {}
    mapper['Plan'] = '{0:.2f} EUR'
    mapper['Forecast'] = '{0:.2f} EUR'
    mapper['AsIs'] = '{0:.2f} EUR'
        
    wp = []
    wp.append('Select...')
    wp.append('Fin Report')
    wp.append('GBS Report')
    
    rep_selection = st.selectbox("Report:", options = wp, key='report')
    if rep_selection == 'Fin Report':
        st.subheader('FIN Report')
        fin_data = service_data.get_fin_data_for_service(it_service)
        listheight = len(fin_data.index) * 40
        fin_data = fin_data.style.format(mapper)
        st.dataframe(fin_data, height=listheight, use_container_width=True)
    elif rep_selection == 'GBS Report':
        # st.markdown('---')
        st.subheader('GBS Report')
        gbs_data = service_data.get_gbs_data_for_service(it_service)
        listheight = len(gbs_data.index) * 40
        st.dataframe(gbs_data, height=listheight, use_container_width=True)

    st.markdown('\n## Reporting Links:')
    st.markdown('- [Ticket KPI](https://tableau.siemens.com/#/site/iRAM/views/4_10_3ITHRKPIDashboard/KPIDashboard?:iid=1)')
    # st.dataframe(service_filter)
   