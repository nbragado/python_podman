# Financial Reporting for GBS H2R DPS 5

The tool developed here shall support the help to generate management report - only. The collection of the data with the service managers etc. is managed in another sub-project.

Further information regarding this tools are not yet described in the wiki.
[Financial Reporting](https://wiki.siemens.com/display/MemberCITCAHS/Concept%3A+Financial+Reporting)

All changes to the code have to documented in the Wiki.


This program ist solely availble for the reporting to the management and not for the processing of SAP, PCT, hour rates, ... 
This is just a Streamlit application reporting the data. 


## Development Tools

This is a python based development so you need:

1. Python - as of now version 3.10
2. Visual Studio Code
3. Git GUI 
4. Access to code.siemens.com - Access to the Fintech project
5. Excel for the template development

## Repositories

The following libraries are required
1. Pandas
2. openpyxl
3. crytography
4. plotly


## Enable httpS

Streamlit does not officially support encrypted communication. The underlying "tornado" software does. 
If required you can add a CRT and a key files to the server.py file. It is located within the the streamlit package within the lib directory.

    \Lib\site-packages\streamlit\web\server


Here you have to add/modify the following line. 

```python

    http_server = HTTPServer(
            app, max_buffer_size=config.get_option("server.maxUploadSize") * 1024 * 1024,
            ssl_options={
                "certfile" : "G:/workspace/finreport/localhost.crt",
                "keyfile" : "G:/workspace/finreport/localhost.key",
            }
        )
```
I just added the `ssl_option` section, with the location of the crt and key file.
It is not yet required as it is planned to have the app protected behind a firewall.



## Development Guideline

You should use Python Virtual Environment. So you can separate your installation from your development. Visual Studio supports Virtual environments.

You can create one by using the following statement:

    python -m venv /path/to/your/project

Starting the virtual environment on the concole is done by using the following statement on Windows:

    scripts/activate

you normally see this on the console having the name of your development folder as a name for the virtual environmenet in front of the path.

    (fintech) PS C:\workspace\fintech


## Docker Configuration

To create a docker image we need some configuration files.

1. Requirements.txt
2. .dockerignore
3. dockerfile

### Content of the dockerignore

