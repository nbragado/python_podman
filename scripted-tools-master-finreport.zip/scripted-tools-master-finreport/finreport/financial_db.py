# coding: utf-8
# from ctypes.wintypes import INT
# from typing import Any

# from sqlalchemy import Column, Date, Float, ForeignKey, String, create_engine
from sqlalchemy import Column, Date, String, create_engine
from sqlalchemy.dialects.sqlite import INTEGER, FLOAT
from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy.orm import relationship

Base = declarative_base()


class PCT(Base):
    '''
    PCT Record as delivered by GBS FIN
    '''
    __tablename__ = 'PCT'

    index = Column(INTEGER, primary_key=True)
    Project = Column(String(200), index=True)
    Sub_Project = Column(String(200), index=True)
    Work_Package = Column(String(200), index=True)
    Date = Column(Date, index=True)
    GID = Column(String(8), index=True)
    Period = Column(INTEGER)
    Name = Column(String(200))
    Extern = Column(String(1))
    Group_Supplier = Column(String(200))
    Hours = Column(FLOAT)
    Fees = Column(FLOAT)
    Comment = Column(String(500))
    Work_Package_ID = Column(String(25))
    Work_Package_Root_ID = Column(String(25))
    Hourly_Rate = Column(FLOAT)
    Hourly_Rate_int = Column(INTEGER)


class PctIds(Base):
    '''
    PCT IDs as calculated form PCT file
    '''
    __tablename__ = 'PCT_IDs'

    index = Column(String[25],primary_key=True)
    Project = Column(String(200), index=True)
    Sub_Project = Column(String(200), index=True)
    Work_Package = Column(String(200), index=True)


class SAPBookings(Base):
    '''
    SAP Bookings
    '''
    __tablename__ = 'SAP_Bookings'

    index = Column(String[25], primary_key=True)
    Project = Column(String(200), index=True)
    Fiscal_Year = Column(INTEGER, index=True)
    Period = Column(INTEGER, index=True)
    Document_Date = Column(Date, index=True)
    Object = Column(String(25), index=True)
    CO_Object_Name = Column(String(200))
    Cost_Element = Column(String(20))
    Cost_element_name = Column(String(20))
    Ref_document_number = Column(String(20))
    Additional_Info2 = Column(String(500))
    Offsetting_Account = Column(String(100))
    Val_COArea_Crcy = Column(String(100))
    Name_of_offsetting_account = Column(String(100))
    Posting_Date = Column(String(100))
    Report_Currency = Column(String(100))
    Name = Column(String(100))
    Document_Header_Text = Column(String(200))
    Company_Code = Column(String(200))
    Partner_Object = Column(String(200))
    Val_in_rep_cur = Column(String(200))
    Responsible_User = Column(String(200))
    Project = Column(String(200))
    Sub_Project = Column(String(200))
    Work_Package = Column(String(200))
    sap_Type = Column(String(200))
    sap_Value = Column(String(200))


def setup(dbname):
    '''
    setup a new database.
    '''
    engine = create_engine('sqlite:///' + dbname)
    # engine = create_engine('sqlite:///' + dbname, echo=True)
    # Base = declarative_base() # type: Any
    metadata = Base.metadata
    metadata.create_all(engine)


def main():
    '''
    just call the main function.
    '''
    engine = create_engine('sqlite:///financial_report_2023.db')
    # Base = declarative_base() # type: Any
    metadata = Base.metadata
    metadata.create_all(engine)


if __name__ == '__main__':
    main()
